
import torch

LOCAL_USE_TANH = False

GLOBAL_TENSOR = torch.FloatTensor(torch.FloatStorage())

